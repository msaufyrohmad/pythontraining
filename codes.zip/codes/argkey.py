#!/usr/bin/env python

def my_function(*args, **kwargs):
    for arg in args:
        print('arg:', arg)
    for key in kwargs.keys():
        print('key:', key, 'has value: ', kwargs[key])

my_function('Saufy','Rohmad',anak_pertama='Musa', anak_kedua='Zainab')
