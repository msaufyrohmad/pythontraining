#!/usr/bin/env python

print('python arithmetic')
a=120
b=222;
print(a+b)
print(a*b)
print(a-b)
print(b%a)
