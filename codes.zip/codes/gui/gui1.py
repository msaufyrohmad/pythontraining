#!/usr/bin/env python

from tkinter import *

def clicked():
    lbl.configure(text="Button was clicked !!")

window = Tk()

window.title("Balik Pulau Smart City")

window.geometry('350x200')

lbl = Label(window, text="Hello")
lbl.grid(column=0, row=0)

btn = Button(window, text="Click Me",command=clicked)
btn2 = Button(window, text="Enter")
btn3 = Button(window, text="Exit")

btn.grid(column=1, row=0)
btn2.grid(column=11, row=0)
btn3.grid(column=21, row=0)

window.mainloop()


