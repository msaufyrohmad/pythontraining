#!/usr/bin/env python

print('Calculator Balik Pulau')

def take_number(msg):
    num=input(msg)
    while not num.isnumeric():
        print('The value need to be a number')
        num=input(msg)
    return int(num)

def add(a,b):
    return a+b

def minus(a,b):
    return a-b

def multiply(a,b):
    return a*b

def divide(a,b):
    return a/b


run=1

while run==1:
    num1=take_number('Enter first number:')
    num2=take_number('Enter second number:')
    answer=0
    select=int(input('Select operation. 1. add 2.minus 3.multiply 4.divide:'))
    if select==1:
        answer=add(num1,num2)
    elif select==2:
        answer=minus(num1,num2)
    elif select==3:
        answer=multiply(num1,num2)
    elif select==4:
        answer=divide(num1,num2)
    else:
        print('Invalid Operation')
    print('The answer is:',answer)




