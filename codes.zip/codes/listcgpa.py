#!/usr/bin/env python

cgpa=[]
count=0
while count<6:
    prompt='enter gpa for sem '+str(count+1)+': '
    gpa=input(prompt)
    cgpa.append(gpa)
    count+=1
for i in range(0,5):
    print('GPA for semester',i+1,' is:',cgpa[i])

