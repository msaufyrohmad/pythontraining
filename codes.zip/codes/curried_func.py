#!/usr/bin/env python

def multiply(a,b):
    return a*b

def multby(func,num):
    return lambda y:func(num,y)

double=multby(multiply,2)
triple=multby(multiply,3)
half=multby(multiply,0.5)

print(double(5))
print(triple(5))
print(half(5))
