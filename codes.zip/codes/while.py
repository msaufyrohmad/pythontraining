#!/usr/bin/env python
count = 0
print('Starting')
while count < 10:
    print(count, ' ', end='') # part of the while loop
    #print(count, ' ') # part of the while loop
    count += 1 # also part of the while loop
print() # not part of the while loop
print('Done')
