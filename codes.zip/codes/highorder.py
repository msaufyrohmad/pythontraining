#!/usr/bin/env python

def testfunc():
    print('test function')

print(testfunc())
ptest=testfunc
print(ptest())

