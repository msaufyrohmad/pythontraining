#!/usr/bin/env python

def runcalc(x):
    x/0

try:
    runcalc(6)
except ZeroDivisionError as err:
    print(err)
    print('oops')

