print('This is calculate module')

def calc(x,y):
    return x*y
