""" this is a module echo inside package saufy """
print('Echo module')

def welcomemsg():
    print('Welcome to Echo')



