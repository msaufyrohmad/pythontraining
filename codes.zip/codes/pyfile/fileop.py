#!/usr/bin/env python

datafile=open("studfile.txt","w+")
datafile.write('test')
datafile.close()

datafile=open("studfile.txt","r+")
rdata=datafile.read()
print(rdata)
datafile.close()


