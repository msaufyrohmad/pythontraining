#!/usr/bin/env python

print('Python file processing')
f=open("database.txt","wt")
for i in range(1,10):
    f.write(str(i))

