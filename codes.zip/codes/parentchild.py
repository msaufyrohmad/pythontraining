#!/usr/bin/env python

class Person:
    def __init__(self,name,age):
        self.name=name
        self.age=age

    def birthday(self):
        print('Happy birthday')

class Employee(Person):
    def __init__(self,name,age,id):
        super().__init__(name,age)
        self.id=id

class Lecturer(Employee):
    def __init__(self,name,age,id,ipt):
        super().__init__(name,age,id)
        self.ipt=ipt


e1=Employee('saufy',19,284664)
print(e1.name)
print(e1.age)
print(e1.id)

L1=Lecturer('Ahmad',20,284664,'UiTM')
print(L1.name)
print(L1.age)
print(L1.id)
print(L1.ipt)
e1.birthday()


