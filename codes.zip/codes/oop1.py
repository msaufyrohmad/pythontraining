#!/usr/bin/env python 

class Person:
    """Person Class that have 3 variables and 3 methods"""
    def __init__(self,name,age,salary):
        """this function is constructor"""
        self.name = name
        self.age = age
        self.salary= salary

    def __str__(self):
        return 'Welcome to Python OOP!'
    
    def get_name(self):
        """this function is constructor"""
        return self.name

    def get_age(self):
        return self.age
    
    def dailysalary(self):
        return self.salary/20;

p1=Person('Ahmad',27,5000)
print('Name:',p1.get_name())
print('Age:',p1.get_age())
print(p1.get_name(), 'daily salary is:RM',p1.dailysalary())
print(p1)
print(Person.__doc__)
print(p1.get_name.__doc__)
print(p1.__doc__)
