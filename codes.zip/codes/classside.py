#!/usr/bin/env python

class Lecturer:
    no_of_lecturer=0;

    @classmethod
    def increment_no_of_lecturer(cls):
        cls.no_of_lecturer+=1
        return cls.no_of_lecturer
   
    @staticmethod
    def classwelcome():
        print('Welcome to Lecturer Class. Class of Your Own Class')

    def __init__(self,name,staffno):
        Lecturer.increment_no_of_lecturer()
        self.name=name
        self.staffno=staffno


A=Lecturer('saufy',284664)
B=Lecturer('saufy',284664)
C=Lecturer('saufy',284664)
D=Lecturer('saufy',284664)
E=Lecturer('saufy',284664)
print('No of object:',Lecturer.no_of_lecturer)
Lecturer.classwelcome()
    
