#!/usr/bin/env python

def apply(x,y,function):
    result = function(x,y)
    return result

def mult(x,y):
    return x*y

def add(x,y):
    return x+y

print('multiply:',apply(5,6,mult))
print('add:',apply(5,6,add))
