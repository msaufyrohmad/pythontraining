#!/usr/bin/env python

import random
print('Number guessing game')
ans=random.randint(1,20)
inp=int(input('Enter your guess number, between 1 to 20:'))
attempt=1
while inp!=ans:
    print('Sorry Wrong Number')
    inp=int(input('Enter your guess number, between 1 to 20:'))
    attempt+=1
    if attempt==4:
        break;
    elif inp>ans:
        print('The answer is smaller than your guess')
    else:
        print('The answer is bigger than your guess')
    

if inp==ans:
    print('You succeed with ',attempt,' attempt')
else:
    print('The answer is ',ans)
    

