#!/usr/bin/env python
str1="Muhammad Saufy Rohmad"
print(str1.count('a')+str1.count('A'))

