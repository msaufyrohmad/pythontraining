#!/usr/bin/env python

list1_credit=[1,1,1,1,1,2,2,2,2,2,3,3,3,3,3,1,1,1,1,1,]
list2_credit=[3,3,3,3,3]
list3_credit=[3,3,3,3,3]
list4_credit=[3,3,3,3,3]
list5_credit=[3,3,3,3,3]
list6_credit=[3,3,3,3,3]

list1_mark=[2,2,2,2,2]
list2_mark=[2,2,2,2,2]
list3_mark=[2,2,2,2,2]
list4_mark=[2,2,2,2,2]
list5_mark=[2,2,2,2,2]
list6_mark=[2,2,2,2,2]


totalcredit=[]
totalmark=[]
for i in range(0,5):
    totalcredit+=list1_credit[i]
    totalmark+=list1_mark[i]*list1_credit[i]
list1_credit.append(totalcredit)
