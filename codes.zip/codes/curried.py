#!/usr/bin/env python

print('Curried Function')

def operation(x,y):return x*y

total=operation(5,2)

print(total)
