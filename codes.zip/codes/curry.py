#!/usr/bin/env python
#add another function to divide the number by half

def multiply(a,b):
    return a*b

def multby(func,num):
    """ this function takes another function and one number as
    argument. It then return lambda function by calling the function
    that passed"""
    return lambda y:func(num,y)

double=multby(multiply,2)
triple=multby(multiply,3)

print(double(5))
print(triple(5))
