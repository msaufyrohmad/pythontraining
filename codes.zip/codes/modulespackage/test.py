#!/usr/bin/env python

import saufy.echo
import saufy.calculate

saufy.echo.welcomemsg()
print(saufy.calculate.calc(10,20))
