#!/usr/bin/env python

class gpa_calculator:
    totalmark=0
    totalcredit=0

    def __init__(self,marks,credit):
        self.marks=marks
        self.credit=credit

    def calculate(self):
        gpa_calculator.totalcredit+=int(credit)
        gpa_calculator.totalmark+=(int(self.marks)*int(self.credit))

    def total_credit_count(self):
        return gpa_calculator.totalcredit

    def total_mark_count(self):
        return gpa_calculator.totalmark

addmore='y'
while addmore == 'y':
    mark=input('enter your marks:')
    credit=input('enter the credit hour:')
    calc=gpa_calculator(mark,credit)
    calc.calculate()
    addmore=input('add another course? (y/n):')
print('Your Total Credit Hour:',calc.total_credit_count())
markT=calc.total_mark_count()
creditT=calc.total_credit_count()
print('Your GPA is : ',markT/creditT)



