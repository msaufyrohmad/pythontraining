#!/usr/bin/env python

def funcret():
    def mult(x,y):
        return x*y
    return mult

f1=funcret()
print(f1(2,2))
print(f1(3,3))
print(f1(4,4))
