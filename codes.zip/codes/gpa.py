#!/usr/bin/env python

courseA=3.00
markcourseA=2.50
courseB=3.00
markcourseB=2.50
courseC=3.00
markcourseC=2.50
courseD=3.00
markcourseD=2.50
courseE=2.00
markcourseE=2.50
totalcredit=14.00
totalmark=(markcourseA*courseA)+(markcourseB*courseB)+(markcourseC*courseC)+(markcourseD*courseD)+(markcourseE*courseE)
gpa=totalmark/totalcredit
formatgpa=float("{:.2f}".format(gpa))
print('Your GPA is : ',formatgpa)
if formatgpa==4.00:
    print('4 Flat student!')
elif formatgpa < 3.99 and formatgpa >= 3.50:
    print('Good,First Class!')
elif formatgpa < 3.49 and formatgpa >=3.00:
    print('Good,Second Class Upper!')
elif formatgpa < 2.99 and formatgpa >= 2.50:
    print('Second Class Lower!')
elif formatgpa < 2.49 and formatgpa >= 2.00:
    print('Third Class!')
else:
    print('You are on class of your own!')





