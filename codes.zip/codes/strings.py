#!/usr/bin/env python

print('python string')

str1='Muhammad'
str2='Saufy'
str3='Rohmad'
str4=str1+' '+str2+' '+str3
print(str4)
print(str4.find('Rohmad'))
