#!/usr/bin/env python

class book:
    how_many_book=0

    def __init__(self,name):
        book.how_many_book+=1
        self.name=name


book1=book('sejarah')
book2=book('sejarah')
book3=book('sejarah')
book4=book('sejarah')
book5=book('sejarah')
book6=book('sejarah')
print('We have:',book.how_many_book,' books')

