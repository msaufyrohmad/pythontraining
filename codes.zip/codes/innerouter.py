#!/usr/bin/env python

def outer():
    title='Original Title'
    def inner():
        nonlocal title
        title='Changed Title'
        print('inner:',title)
    inner()
    print('outer:',title)

outer()
