#!/usr/bin/env python
print('Module 2 file for demo')

def multiply(x,y):
    return x*y
