#!/usr/bin/env python

import demo_mod1
import demo_mod2

print(demo_mod1.add(10,20))
print(demo_mod2.multiply(10,20))
