#!/usr/bin/env python
print('Module 1 file for demo')

def add(x,y):
    return x+y
