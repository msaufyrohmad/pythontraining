#!/usr/bin/env python

def runcalc(x):
    x/0


runcalc(6)
