#!/usr/bin/env python

addmore='y'
totalmark=0
totalcredit=0
while addmore == 'y':
    mark=input('enter your marks:')
    credit=input('enter the credit hour:')
    totalcredit+=int(credit)
    totalmark+=int(mark)*int(credit)
    addmore=input('add another course? (y/n):')

print('Your Total Credit Hour:',totalcredit)
gpa=totalmark/totalcredit
print('Your GPA is : ',gpa)



