#!/usr/bin/env python

def print_msg(msg):
    """this function print the cool msg on screen that take msg as argument"""
    print('MSG:',msg)


def swap(a,b):
    return b,a

print_msg('Python is cool')
ans=swap(10,20)
print(ans)
c,d=swap(10,20)
print(c,d)
print(print_msg.__doc__)
